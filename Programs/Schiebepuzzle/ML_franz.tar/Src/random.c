/**
 ******************************************************************************
 * @file    random.c
 * @author  Franz Korf
 *          HAW-Hamburg
 *          Labor fuer technische Informatik
 *          Berliner Tor  7
 *          D-20099 Hamburg
 * @version 1.0
 *
 * @date    10. Jan. 2026
 * @brief   Dieses Modul kapselt den Standard-Pseudozufallsgenerator.
 ******************************************************************************
 */
 
#include "random.h"
#include <stdlib.h>
#include <stdbool.h>

int nxtRandNumber(void){
   const unsigned int seed = 1302;
   static bool firstCall = true;
   if (firstCall) {
      firstCall = false;
      srand(seed);
   }
   int erg = rand();
   return erg;
}
// EOF