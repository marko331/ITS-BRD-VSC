/**
 ******************************************************************************
 * @file    display.c
 * @author  Franz Korf
 *          HAW-Hamburg
 *          Labor fuer technische Informatik
 *          Berliner Tor  7
 *          D-20099 Hamburg
 * @version 1.0
 *
 * @date    10. Jan. 2026
 * @brief   Dieses Modul implementiert die LCD Ausgabe des Spielfelds.
 ******************************************************************************
 */

#include "display.h"
#include "fontsFLASH.h"
#include "main.h"
#include "LCD_general.h"
#include "error.h"
#include "LCD_GUI.h"

/**
 * @defgroup DISPLAY_CONS 
 * @brief Die Konstanten dieser Gruppe definieren die Abmaße
 *        der Elemente des Spielfelds in Pixel.
 */

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert die Kantenlänge der quadratischen Spielsteine
 *        in Pixel.
 */
#define E_S         		90

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert den Abstand zwischen zwei Spielsteinen
 *.       in Pixel.
 */
#define GAP                	 5

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert die Display-Zeile des oberen linken Felds.
 */
#define TL_X 			    95

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert die Display-Spalte des oberen linken Felds.
 */
#define TL_Y 				15

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert die Farbe eines freien Felds.
 */
#define CLR_NO_PIECE 	    BLACK

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert die Farbe eines Spielsteins.
 */
#define CLR_PIECE          GREEN

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert die Farbe der Zahl auf einem Spielstein.
 */
#define CLR_PIECE_FONT		BLUE

/**
 * @ingroup DISPLAY_CONS
 * @brief Diese Konstante definiert den Font der Zahl auf einem Spielstein.
 */
#define PIECE_FONT		FiraMono60FLASH

/**
 * @ingroup DISPLAY_CONS
 * @brief Dieses Feld definiert die Display-Positionen der 9 Felder. 
 *
 * Die erste Felddimension entspricht der Zeile des Spielfelds. Die zweite 
 * Felddimension entspricht der Spalte des Spielfelds. Somit liefert
 * field_pos[0][1] die Bildschirmposition des mittleren Felds der oberen
 * Zeile des Spielfelds.
 *
 * Die Display-Position eines Felds wird über die Koordinaten linke 
 * obere (tr) und rechte untere (br) Ecke des Rechtecks, das das Feld
 * aufspannt, definiert. Diese Koordinaten können direkt an die 
 * GUI_drawRectangle Funktion übergeben werden.
 */

const struct {
	 Coordinate tl;
	 Coordinate br;
	} field_pos[GRID_SIZE][GRID_SIZE]  = {
			{ // obere Zeile
		        // Feld oben links
				{.tl = {.x = TL_X, .y = TL_Y}, 
				 .br = {.x = TL_X + E_S, .y = TL_Y + E_S}},
				// Feld oben mitte
				{.tl = {.x = TL_X + E_S + GAP, .y = TL_Y}, 
				 .br = {.x = TL_X + E_S + GAP + E_S, .y = TL_Y + E_S}},
				// Feld oben rechts
				{.tl = {.x = TL_X + E_S + GAP + E_S + GAP, .y = TL_Y}, 
				 .br = {.x = TL_X + E_S + GAP + E_S + GAP+ E_S, .y = TL_Y + E_S}} },
			{ // mittlere Zeile
		        // Feld mitte links
				{.tl = {.x = TL_X, .y = TL_Y + E_S + GAP}, 
				 .br = {.x = TL_X + E_S, .y = TL_Y + E_S + GAP + E_S}},
				// Feld mitte mitte
				{.tl = {.x = TL_X + E_S + GAP, .y = TL_Y + E_S + GAP}, 
				 .br = {.x = TL_X + E_S + GAP + E_S, .y = TL_Y + E_S + GAP + E_S}},
				// Feld mitte rechts
				{.tl = {.x = TL_X + E_S + GAP + E_S + GAP, .y = TL_Y + E_S + GAP}, 
				 .br = {.x = TL_X + E_S + GAP + E_S + GAP + E_S, .y = TL_Y + E_S + GAP + E_S} } },
			{ // untere Zeile
		        // Feld unten links
				{.tl = {.x = TL_X, .y = TL_Y + E_S + GAP + E_S + GAP}, 
				 .br = {.x = TL_X + E_S, .y = TL_Y + E_S + GAP + E_S + GAP + E_S}},
				// Feld unten mitte
				{.tl = {.x = TL_X + E_S + GAP, .y = TL_Y + E_S + GAP + E_S + GAP}, 
				 .br = {.x = TL_X + E_S + GAP + E_S, .y = TL_Y + E_S + GAP + E_S + GAP + E_S}},
				// Feld unten rechts
				{.tl = {.x = TL_X + E_S + GAP + E_S + GAP, .y = TL_Y + E_S + GAP + E_S + GAP}, 
				 .br = {.x = TL_X + E_S + GAP + E_S + GAP + E_S, .y = TL_Y + E_S + GAP + E_S + GAP + E_S}} }};

// EOF