/**
 ******************************************************************************
 * @file    kniffel.c
 * @author  Franz Korf
 *          HAW-Hamburg
 *          Labor fuer technische Informatik
 *          Berliner Tor  7
 *          D-20099 Hamburg
 * @version 1.1
 *
 * @date    10. Jan. 2026
 * @brief   Dieses Modul implementiert die Spiellogik.
 *
 ******************************************************************************
 */

#include "game.h"


// EOF