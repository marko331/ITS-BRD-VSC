/**
  ******************************************************************************
  * @file    main.c
  * @author  Franz Korf
  * @brief   Klausuraufgabe Schiebepuzzle WS 25/26.
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/

#include "init.h"
#include "io.h"
#include "display.h"
#include "LCD_Touch.h"
#include "delay.h"
#include "game.h"
#include "LCD_GUI.h"
#include <stdint.h>
#include <test.h>

int main(void) {
	initITSboard();    // Initialisierung des ITS Boards
	GUI_init(DEFAULT_BRIGHTNESS);   // Initialisierung des LCD Boards mit Touch
	TP_Init(false);                 // Initialisierung des LCD Boards mit Touch

#ifdef AUFGABE3
   test_IO();
#endif

#ifdef AUFGABE4
   test_display();
#endif

#ifdef AUFGABE5 
	 test_game();
#endif

	// Initialisierung

	// Super loop gemäß DDC
	while(1) {
		
	}
}
// EOF